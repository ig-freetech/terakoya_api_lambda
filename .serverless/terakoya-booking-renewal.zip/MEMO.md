## Set a secret for GitHub Actions

1. `gh auth login`
2. `gh secret set ENV_FILE_CONTENTS -b "$(cat .env)"`

■Ref
- https://cli.github.com/manual/gh_secret_set
- https://github.com/cli/cli/pull/4534

## ZIP ファイル化

`zip -r functions_dev.zip ./functions -x '*python*' '*__pycache__*' '*.pytest_cache*' '*tmp*'`

`zip -r functions_prod.zip ./functions -x '*python*' '*__pycache__*' '*.pytest_cache*' '*tmp*'`

`zip -r layer_dev.zip ./functions/python`

`zip -r layer_prod.zip ./functions/python`

## S3 へアップロード

`awst s3 cp ./functions_dev.zip s3://terakoya-bucket/lambda/booking/`

`awst s3 cp ./functions_prod.zip s3://terakoya-bucket/lambda/booking/`

`awst s3 cp ./layer_dev.zip s3://terakoya-bucket/lambda/booking/`

`awst s3 cp ./layer_prod.zip s3://terakoya-bucket/lambda/booking/`

## Layer 更新(作成)

`awst lambda publish-layer-version --layer-name terakoya-booking-dev-layer --content S3Bucket=terakoya-bucket,S3Key=lambda/booking/layer_dev.zip --compatible-runtimes python3.9 --compatible-architectures x86_64 arm64`

`awst lambda publish-layer-version --layer-name terakoya-booking-prod-layer --content S3Bucket=terakoya-bucket,S3Key=lambda/booking/layer_prod.zip --compatible-runtimes python3.9 --compatible-architectures x86_64 arm64`

## Lambda 関数作成

- layer version のみ要確認

##### dev

`awst lambda create-function --function-name terakoya-booking-dev-book --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_dev.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,TERAKOYA_GMAIL_ADDRESS=npoterakoya2021@gmail.com,TERAKOYA_GROUP_MAIL_ADDRESS=info@npoterakoya.org,DYNAMO_DB_BOOKING_TABLE=booking_dev}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda create-function --function-name terakoya-booking-dev-remind --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.remind.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_dev.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,TERAKOYA_GMAIL_ADDRESS=npoterakoya2021@gmail.com,TERAKOYA_GROUP_MAIL_ADDRESS=info@npoterakoya.org,DYNAMO_DB_BOOKING_TABLE=booking_dev}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda create-function --function-name terakoya-booking-dev-login --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.login.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_dev.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_dev}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda create-function --function-name terakoya-booking-dev-book-list --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book_list.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_dev.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_dev}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda create-function --function-name terakoya-booking-dev-book-edit-place --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book_edit_place.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_dev.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_dev}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

##### prod

`awst lambda create-function --function-name terakoya-booking-prod-book --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_prod.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,TERAKOYA_GMAIL_ADDRESS=npoterakoya2021@gmail.com,TERAKOYA_GROUP_MAIL_ADDRESS=info@npoterakoya.org,DYNAMO_DB_BOOKING_TABLE=booking_prod}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda create-function --function-name terakoya-booking-prod-remind --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.remind.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_prod.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,TERAKOYA_GMAIL_ADDRESS=npoterakoya2021@gmail.com,TERAKOYA_GROUP_MAIL_ADDRESS=info@npoterakoya.org,DYNAMO_DB_BOOKING_TABLE=booking_prod}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda create-function --function-name terakoya-booking-prod-login --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.login.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_prod.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_prod}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda create-function --function-name terakoya-booking-prod-book-list --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book_list.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_prod.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_prod}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda create-function --function-name terakoya-booking-prod-book-edit-place --runtime python3.9 --role arn:aws:iam::737476809857:role/CustomAWSLambdaEnableCloudWatchS3 --handler functions.book_edit_place.lambda_handler --code S3Bucket=terakoya-bucket,S3Key=lambda/booking/functions_prod.zip --timeout 10 --architecture arm64 --environment "Variables={ACCESS_KEY=AKIA2XNILCSA2EVXECQH,SECRET_ACCESS_KEY=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,DEFAULT_REGION=ap-northeast-1,DYNAMO_DB_BOOKING_TABLE=booking_prod}" --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

## Lambda 関数ソースコード更新

##### dev

`awst lambda update-function-code --function-name terakoya-booking-dev-book --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_dev.zip`

`awst lambda update-function-code --function-name terakoya-booking-dev-remind --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_dev.zip`

`awst lambda update-function-code --function-name terakoya-booking-dev-login --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_dev.zip`

`awst lambda update-function-code --function-name terakoya-booking-dev-book-list --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_dev.zip`

`awst lambda update-function-code --function-name terakoya-booking-dev-book-edit-place --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_dev.zip`

##### prod

`awst lambda update-function-code --function-name terakoya-booking-prod-book --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_prod.zip`

`awst lambda update-function-code --function-name terakoya-booking-prod-remind --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_prod.zip`

`awst lambda update-function-code --function-name terakoya-booking-prod-login --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_prod.zip`

`awst lambda update-function-code --function-name terakoya-booking-prod-book-list --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_prod.zip`

`awst lambda update-function-code --function-name terakoya-booking-prod-book-edit-place --s3-bucket terakoya-bucket --s3-key lambda/booking/functions_prod.zip`

## Lambda 関数に紐づく Layer を更新

##### dev

`awst lambda update-function-configuration --function-name terakoya-booking-dev-book --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-dev-remind --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-dev-login --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-dev-book-list --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-dev-book-edit-place --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-dev-layer:1`

##### prod

`awst lambda update-function-configuration --function-name terakoya-booking-prod-book --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-prod-remind --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-prod-login --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-prod-book-list --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

`awst lambda update-function-configuration --function-name terakoya-booking-prod-book-edit-place --layers arn:aws:lambda:ap-northeast-1:737476809857:layer:terakoya-booking-prod-layer:1`

## API Gateway 作成

`awst apigatewayv2 create-api --name terakoya-booking-dev-agw --protocol-type HTTP --cors-configuration AllowHeaders="*",AllowMethods="*",AllowOrigins="*",ExposeHeaders="*"`

`awst apigatewayv2 create-api --name terakoya-booking-prod-agw --protocol-type HTTP --cors-configuration AllowHeaders="*",AllowMethods="*",AllowOrigins="*",ExposeHeaders="*"`

- stage 名を v1 にする
- 自動デプロイを ON にする
- ルートと統合を追加する

## Event Trigger 設定

- EventBridge (CloudWatch Events) でスケジュール式 `cron(0 0,7 ? * TUE,SAT *)` の新規イベントを作成して remind にアタッチ

## Dyanmo DB テーブル作成

- PK は「date」SK は「sk」(共に文字列)
- テーブル設定はカスタマイズ > 書き込み/読み書きキャパシティーの設定を「オンデマンド」に設定
- インデックスは作成不要

## 注意事項

- Lambda では dotenv が import できないためコメントアウトしないと 500 Internal Server Error になる
